# VOICES of OKC Press Kit

This folder contains public-facing brand and press materials for VOICES of OKC, a City Center podcast. These files are intended for media, guests, partners, event listings, and basic promotion of the show.

Please use the logo files as provided. Do not stretch, recolor, distort, crop, add effects, or place the icon on a background where it loses contrast. Use the Civic Navy icon on light backgrounds and the White icon on dark backgrounds.

For anything not included here, email info@voicesofokc.com.
