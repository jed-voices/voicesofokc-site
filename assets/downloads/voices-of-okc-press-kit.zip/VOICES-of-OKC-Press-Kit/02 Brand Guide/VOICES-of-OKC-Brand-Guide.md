# VOICES of OKC Brand Guide

## Brand Colors

- Civic Navy: #0F2A44
- Azure: #5FA8D3
- Slate: #3E4C59
- Cloud White: #F4F7FA

Use these colors only. Do not recolor the logo or create alternate color versions.

## Logo Use

Use the VOICES of OKC icon as provided. Keep clear space around the mark. Do not stretch, recolor, rotate, outline, crop, distort, or add shadows or other effects.

Use the Civic Navy icon on light backgrounds. Use the White icon on dark backgrounds. Use the Azure icon only when it fits the existing VOICES of OKC visual system and has enough contrast.

## Tone

VOICES of OKC should feel reflective, civic-minded, thoughtful, and human. The show is grounded in Oklahoma City and the people shaping it. Avoid hype, clever slogans, and language that feels like advertising.
