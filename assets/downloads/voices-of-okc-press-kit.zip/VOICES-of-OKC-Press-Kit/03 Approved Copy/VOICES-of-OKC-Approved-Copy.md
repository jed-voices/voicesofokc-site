# VOICES of OKC Approved Copy

## About the Show, Short

A student-produced civic podcast from City Center spotlighting the people, stories, and ideas shaping Oklahoma City.

## About the Show, Longer

VOICES of OKC is a student-produced podcast from City Center featuring the leaders, founders, mentors, and public servants shaping Oklahoma City. Each episode is a thoughtful, unhurried conversation built to help listeners understand the city and the people moving it forward. Production is led by students, who gain real experience in interviewing, audio, and storytelling through the work itself.

## Founder and Host

Jed Chappell is the founder and CEO of City Center, a nonprofit he and his wife Julie started in 2016 to bring relief and restoration to youth and families in under-resourced Oklahoma City neighborhoods. He later became a pastor, and on VOICES of OKC he sits down with local leaders and neighbors to explore how hope gets built, one story and one relationship at a time.

## Approved Language

Partners are welcome to use this verbatim:

"VOICES of OKC is a student-produced podcast from City Center sharing stories that help us see Oklahoma City more clearly. New episodes feature local leaders and changemakers in thoughtful, in-depth conversation."

## Sample Event or Partner Copy

"VOICES of OKC, a student-produced podcast from City Center, brings you grounded conversations with the people shaping Oklahoma City. Listen on YouTube, Spotify, and Apple Podcasts."

## Contact

Media or partnership requests: info@voicesofokc.com
